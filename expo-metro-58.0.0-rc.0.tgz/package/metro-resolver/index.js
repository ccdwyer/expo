module.exports = require("metro-resolver");
module.exports.default = module.exports;