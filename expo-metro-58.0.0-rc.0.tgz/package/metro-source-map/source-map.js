module.exports = require("metro-source-map/private/source-map");
module.exports.default = module.exports;