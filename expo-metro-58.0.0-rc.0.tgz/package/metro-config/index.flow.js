module.exports = require("metro-config/private/index.flow");
module.exports.default = module.exports;