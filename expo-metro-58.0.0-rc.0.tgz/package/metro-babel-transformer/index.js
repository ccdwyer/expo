module.exports = require("metro-babel-transformer");
module.exports.default = module.exports;