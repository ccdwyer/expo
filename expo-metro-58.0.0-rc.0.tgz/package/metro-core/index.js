module.exports = require("metro-core");
module.exports.default = module.exports;