module.exports = require("metro-cache");
module.exports.default = module.exports;