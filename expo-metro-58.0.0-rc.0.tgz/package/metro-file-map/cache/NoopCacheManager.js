module.exports = require("metro-file-map/private/cache/NoopCacheManager");
module.exports.default = module.exports;