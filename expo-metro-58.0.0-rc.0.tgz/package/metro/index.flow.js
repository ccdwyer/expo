module.exports = require("metro/private/index.flow");
module.exports.default = module.exports;