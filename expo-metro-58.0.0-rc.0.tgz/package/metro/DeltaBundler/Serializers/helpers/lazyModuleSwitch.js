module.exports = require("metro/private/DeltaBundler/Serializers/helpers/lazyModuleSwitch");
module.exports.default = module.exports;