/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @oncall react_native
 * @generated SignedSource<<85abaea953f4004290e48d209d02a4e3>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro/src/index.flow.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {AssetData} from './Assets';
import type {ReadOnlyGraph} from './DeltaBundler';
import type {ServerOptions} from './Server';
import type {BuildOptions, OutputOptions, RequestOptions} from './shared/types';
import type {HandleFunction} from 'connect';
import type {TransformProfile} from '../metro-babel-transformer';
import type {ConfigT, InputConfigT, MetroConfig, Middleware} from '../metro-config';
import type {CustomResolverOptions} from '../metro-resolver';
import type {CustomTransformOptions} from '../metro-transform-worker';
import type {Server as HttpServer} from 'node:http';
import type {Server as HttpsServer, ServerOptions as HttpsServerOptions} from 'node:https';
import type {Server as WebSocketServer} from 'ws';
import type $$IMPORT_TYPEOF_1$$ from 'yargs';

import getSchemeResolvers from './lib/getSchemeResolvers';
import JsonReporter from './lib/JsonReporter';
import TerminalReporter from './lib/TerminalReporter';
import MetroServer from './Server';
import {loadConfig, mergeConfig, resolveConfig} from '../metro-config';
import {Terminal} from '../metro-core';

type Yargs = typeof $$IMPORT_TYPEOF_1$$;
type MetroMiddleWare = {
  attachHmrServer: (httpServer: HttpServer | HttpsServer) => void;
  end: () => Promise<void>;
  metroServer: MetroServer;
  middleware: Middleware;
};
export type RunMetroOptions = Omit<ServerOptions, 'waitForBundler'> & {
  waitForBundler?: boolean | undefined;
};
export type RunServerOptions = Readonly<{
  hasReducedPerformance?: boolean | undefined;
  host?: string | undefined;
  onError?: ((err: Error & {code?: string | undefined}) => void) | undefined;
  onReady?: ((server: HttpServer | HttpsServer) => void) | undefined;
  onClose?: (() => void) | undefined;
  secureServerOptions?: HttpsServerOptions | undefined;
  secure?: boolean | undefined;
  secureCert?: string | undefined;
  secureKey?: string | undefined;
  unstable_extraMiddleware?: ReadonlyArray<HandleFunction> | undefined;
  waitForBundler?: boolean | undefined;
  watch?: boolean | undefined;
  websocketEndpoints?: Readonly<{[path: string]: WebSocketServer}> | undefined;
}>;
export type RunServerResult = {httpServer: HttpServer | HttpsServer};
type BuildGraphOptions = {
  entries: ReadonlyArray<string>;
  customTransformOptions?: CustomTransformOptions | undefined;
  dev?: boolean | undefined;
  minify?: boolean | undefined;
  onProgress?: ((transformedFileCount: number, totalFileCount: number) => void) | undefined;
  platform?: string | undefined;
  type?: 'module' | 'script' | undefined;
};
export type RunBuildOptions = {
  entry: string;
  assets?: boolean | undefined;
  dev?: boolean | undefined;
  out?: string | undefined;
  bundleOut?: string | undefined;
  sourceMapOut?: string | undefined;
  onBegin?: (() => void) | undefined;
  onComplete?: (() => void) | undefined;
  onProgress?: ((transformedFileCount: number, totalFileCount: number) => void) | undefined;
  minify?: boolean | undefined;
  output?:
    | Readonly<{
        build: (
          server: MetroServer,
          requestOptions: RequestOptions,
          buildOptions?: BuildOptions,
        ) => Promise<{
          code: string;
          map: string;
          assets?: ReadonlyArray<AssetData> | undefined;
        }>;
        save: (output: {code: string; map: string}, opts: OutputOptions, logger: (logMessage: string) => void) => Promise<unknown>;
      }>
    | undefined;
  platform?: string | undefined;
  sourceMap?: boolean | undefined;
  sourceMapUrl?: string | undefined;
  customResolverOptions?: CustomResolverOptions | undefined;
  customTransformOptions?: CustomTransformOptions | undefined;
  unstable_transformProfile?: TransformProfile | undefined;
};
export type RunBuildResult = {
  code: string;
  map: string;
  assets?: ReadonlyArray<AssetData> | undefined;
};
type BuildCommandOptions = Readonly<{[$$Key$$: string]: unknown}> | null;
type ServeCommandOptions = Readonly<{[$$Key$$: string]: unknown}> | null;
type DependenciesCommandOptions = Readonly<{
  [$$Key$$: string]: unknown;
}> | null;
export {Terminal, JsonReporter, TerminalReporter, getSchemeResolvers};
export type {AssetData} from './Assets';
export type {
  AsyncDependencyType,
  DeltaResult,
  Dependency,
  MixedOutput,
  Module,
  ReadOnlyDependencies,
  ReadOnlyGraph,
  SerializerOptions,
  TransformInputOptions,
  TransformResult,
  TransformResultDependency,
} from './DeltaBundler/types';
export type {default as DependencyGraph} from './node-haste/DependencyGraph';
export type {BundleDetails, Reporter, ReportableEvent} from './lib/reporting';
export type {TerminalReportableEvent} from './lib/TerminalReporter';
export type {ContextMode, RequireContextParams} from './ModuleGraph/worker/collectDependencies';
export type {ServerOptions} from './Server';
export type {MetroConfig, MetroServer};
export declare function runMetro(config: InputConfigT, options?: RunMetroOptions): Promise<MetroServer>;
export {loadConfig, mergeConfig, resolveConfig};
export declare const createConnectMiddleware: (config: ConfigT, options?: RunMetroOptions) => Promise<MetroMiddleWare>;
export declare type createConnectMiddleware = typeof createConnectMiddleware;
export declare const runServer: (config: ConfigT, opts?: RunServerOptions) => Promise<RunServerResult>;
export declare type runServer = typeof runServer;
export declare const runBuild: (config: ConfigT, opts: RunBuildOptions) => Promise<RunBuildResult>;
export declare type runBuild = typeof runBuild;
export declare const buildGraph: (config: InputConfigT, opts: BuildGraphOptions) => Promise<ReadOnlyGraph>;
export declare type buildGraph = typeof buildGraph;
type AttachMetroCLIOptions = {
  build?: BuildCommandOptions | undefined;
  serve?: ServeCommandOptions | undefined;
  dependencies?: DependenciesCommandOptions | undefined;
};
export declare const attachMetroCli: (yargs: Yargs, options?: AttachMetroCLIOptions) => Yargs;
export declare type attachMetroCli = typeof attachMetroCli;
