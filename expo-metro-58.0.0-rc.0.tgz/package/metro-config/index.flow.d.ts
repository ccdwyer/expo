import getDefaultConfig from "./defaults";
import { loadConfig, mergeConfig, resolveConfig } from "./loadConfig";
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow strict-local
 * @format
 * @oncall react_native
 */

export type * from "./types";
export { getDefaultConfig, loadConfig, mergeConfig, resolveConfig };