/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @oncall react_native
 * @generated SignedSource<<28adf6a73ac44ebedccde58255d3e949>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro-config/src/types.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {HandleFunction, Server} from 'connect';
import type {CacheStore, MetroCache} from '../metro-cache';
import type {CacheManagerFactory, InputFileMapPlugin} from '../metro-file-map';
import type {CustomResolver} from '../metro-resolver';
import type {JsTransformerConfig} from '../metro-transform-worker';
import type {DeltaResult, Module, ReadOnlyGraph, SerializerOptions, TransformResult} from '../metro/DeltaBundler/types';
import type {Reporter} from '../metro/lib/reporting';
import type MetroServer from '../metro/Server';
import type {IntermediateStackFrame} from '../metro/Server/symbolicate';

export type ExtraTransformOptions = Readonly<{
  preloadedModules?: Readonly<{[path: string]: true}> | false | undefined;
  ramGroups?: ReadonlyArray<string> | undefined;
  transform?:
    | Readonly<{
        experimentalImportSupport?: boolean | undefined;
        inlineRequires?:
          | Readonly<{
              blockList: Readonly<{[absoluteModulePath: string]: true}>;
            }>
          | boolean
          | undefined;
        nonInlinedRequires?: ReadonlyArray<string> | undefined;
        unstable_memoizeInlineRequires?: boolean | undefined;
        unstable_nonMemoizedInlineRequires?: ReadonlyArray<string> | undefined;
      }>
    | undefined;
}>;
export type GetTransformOptionsOpts = {
  dev: boolean;
  /**
   * @deprecated Always true
   */
  hot: true;
  platform: null | undefined | string;
};
export type GetTransformOptions = (
  entryPoints: ReadonlyArray<string>,
  options: GetTransformOptionsOpts,
  getDependenciesOf: (absoluteFilePath: string) => Promise<Array<string>>,
) => Promise<Partial<ExtraTransformOptions>>;
export type Middleware = HandleFunction;
type PerfAnnotations = Partial<{
  string: Readonly<{[key: string]: string}>;
  int: Readonly<{[key: string]: number}>;
  double: Readonly<{[key: string]: number}>;
  bool: Readonly<{[key: string]: boolean}>;
  string_array: Readonly<{[key: string]: ReadonlyArray<string>}>;
  int_array: Readonly<{[key: string]: ReadonlyArray<number>}>;
  double_array: Readonly<{[key: string]: ReadonlyArray<number>}>;
  bool_array: Readonly<{[key: string]: ReadonlyArray<boolean>}>;
}>;
type PerfLoggerPointOptions = Readonly<{timestamp?: number | undefined}>;
export interface PerfLogger {
  point(name: string, opts?: PerfLoggerPointOptions): void;
  annotate(annotations: PerfAnnotations): void;
  subSpan(label: string): PerfLogger;
}
export interface RootPerfLogger extends PerfLogger {
  start(opts?: PerfLoggerPointOptions): void;
  end(status: 'SUCCESS' | 'FAIL' | 'CANCEL', opts?: PerfLoggerPointOptions): void;
}
export type PerfLoggerFactoryOptions = Readonly<{key?: number | undefined}>;
export type PerfLoggerFactory = (type: 'START_UP' | 'BUNDLING_REQUEST' | 'HMR', opts?: PerfLoggerFactoryOptions) => RootPerfLogger;
type ResolverConfigT = {
  assetExts: ReadonlyArray<string>;
  assetResolutions: ReadonlyArray<string>;
  blockList: RegExp | Array<RegExp>;
  disableHierarchicalLookup: boolean;
  dependencyExtractor: null | undefined | string;
  emptyModulePath: string;
  enableGlobalPackages: boolean;
  extraNodeModules: {[packageName: string]: string};
  hasteImplModulePath: null | undefined | string;
  nodeModulesPaths: ReadonlyArray<string>;
  platforms: ReadonlyArray<string>;
  resolveRequest: null | undefined | CustomResolver;
  resolverMainFields: ReadonlyArray<string>;
  schemeResolvers: Readonly<{[scheme: string]: CustomResolver}>;
  sourceExts: ReadonlyArray<string>;
  unstable_conditionNames: ReadonlyArray<string>;
  unstable_conditionsByPlatform: Readonly<{
    [platform: string]: ReadonlyArray<string>;
  }>;
  unstable_enablePackageExports: boolean;
  unstable_incrementalResolution: boolean;
  useWatchman: boolean;
  requireCycleIgnorePatterns: ReadonlyArray<RegExp>;
  unstable_forceFullRefreshPatterns: ReadonlyArray<RegExp>;
};
type SerializerConfigT = {
  createModuleIdFactory: () => (path: string) => number;
  customSerializer: null | undefined | ((entryPoint: string, preModules: ReadonlyArray<Module>, graph: ReadOnlyGraph, options: SerializerOptions) => Promise<string | {code: string; map: string}>);
  experimentalSerializerHook: (graph: ReadOnlyGraph, delta: DeltaResult) => unknown;
  getModulesRunBeforeMainModule: (entryFilePath: string) => Array<string>;
  getPolyfills: (ctx: {platform: null | undefined | string}) => ReadonlyArray<string>;
  getRunModuleStatement: (moduleId: number | string, globalPrefix: string) => string;
  polyfillModuleNames: ReadonlyArray<string>;
  processModuleFilter: (modules: Module) => boolean;
  isThirdPartyModule: (module: Readonly<{path: string}>) => boolean;
  unstable_inlineDependencyMap: boolean;
  unstable_lazilyDefineModules: boolean;
};
type TransformerConfigT = Omit<JsTransformerConfig, 'getTransformOptions' | 'transformVariants' | 'publicPath' | 'unstable_workerThreads'> & {
  getTransformOptions: GetTransformOptions;
  transformVariants: {
    readonly [name: string]: Partial<ExtraTransformOptions>;
  };
  publicPath: string;
  unstable_workerThreads: boolean;
};
type MetalConfigT = {
  cacheVersion: string;
  fileMapCacheDirectory?: string | undefined;
  hasteMapCacheDirectory?: string | undefined;
  unstable_fileMapCacheManagerFactory?: CacheManagerFactory | undefined;
  unstable_fileMapPlugins?: ReadonlyArray<InputFileMapPlugin> | undefined;
  maxWorkers: number;
  unstable_perfLoggerFactory?: null | undefined | PerfLoggerFactory;
  projectRoot: string;
  stickyWorkers: boolean;
  transformerPath: string;
  reporter: Reporter;
  resetCache: boolean;
  watchFolders: ReadonlyArray<string>;
};
type CacheStoresConfigT = ReadonlyArray<CacheStore<TransformResult>>;
type ServerConfigT = {
  /** @deprecated */
  enhanceMiddleware: (middleware: Middleware, server: MetroServer) => Middleware | Server;
  forwardClientLogs: boolean;
  port: number;
  rewriteRequestUrl: (url: string) => string;
  unstable_serverRoot: null | undefined | string;
  useGlobalHotkey: boolean;
  verifyConnections: boolean;
  tls:
    | false
    | {
        ca?: string | Buffer | undefined;
        cert?: string | Buffer | undefined;
        key?: string | Buffer | undefined;
        requestCert?: boolean | undefined;
      };
};
type SymbolicatorConfigT = {
  customizeFrame: (frame: {
    readonly file: null | undefined | string;
    readonly lineNumber: null | undefined | number;
    readonly column: null | undefined | number;
    readonly methodName: null | undefined | string;
  }) => (null | undefined | {readonly collapse?: boolean | undefined}) | Promise<null | undefined | {readonly collapse?: boolean | undefined}>;
  customizeStack: (symbolicatedStack: Array<IntermediateStackFrame>, extraData: unknown) => Array<IntermediateStackFrame> | Promise<Array<IntermediateStackFrame>>;
};
type WatcherConfigT = {
  additionalExts: ReadonlyArray<string>;
  healthCheck: Readonly<{
    enabled: boolean;
    interval: number;
    timeout: number;
    filePrefix: string;
  }>;
  unstable_autoSaveCache: Readonly<{
    enabled: boolean;
    debounceMs?: number | undefined;
  }>;
  unstable_lazySha1: boolean;
  watchman: Readonly<{deferStates: ReadonlyArray<string>}>;
};
export type InputConfigT = Partial<
  Readonly<
    MetalConfigT & {
      cacheStores: CacheStoresConfigT | ((metroCache: MetroCache) => CacheStoresConfigT);
      resolver: Readonly<Partial<ResolverConfigT>>;
      server: Readonly<Partial<ServerConfigT>>;
      serializer: Readonly<Partial<SerializerConfigT>>;
      symbolicator: Readonly<Partial<SymbolicatorConfigT>>;
      transformer: Readonly<Partial<TransformerConfigT>>;
      watcher: Partial<
        Readonly<
          Omit<WatcherConfigT, 'healthCheck' | 'unstable_autoSaveCache' | 'watchman'> & {
            healthCheck: Partial<Readonly<WatcherConfigT['healthCheck']>>;
            unstable_autoSaveCache: Partial<Readonly<WatcherConfigT['unstable_autoSaveCache']>>;
            watchman: Partial<Readonly<WatcherConfigT['watchman']>>;
          }
        >
      >;
    }
  >
>;
export type MetroConfig = InputConfigT;
export type ConfigT = Readonly<
  MetalConfigT & {
    cacheStores: CacheStoresConfigT;
    resolver: Readonly<ResolverConfigT>;
    server: Readonly<ServerConfigT>;
    serializer: Readonly<SerializerConfigT>;
    symbolicator: Readonly<SymbolicatorConfigT>;
    transformer: Readonly<TransformerConfigT>;
    watcher: Readonly<WatcherConfigT>;
  }
>;
export type YargArguments = Readonly<{
  config?: string | undefined;
  cwd?: string | undefined;
  port?: string | number | undefined;
  host?: string | undefined;
  projectRoot?: string | undefined;
  watchFolders?: Array<string> | undefined;
  assetExts?: Array<string> | undefined;
  sourceExts?: Array<string> | undefined;
  platforms?: Array<string> | undefined;
  'max-workers'?: string | number | undefined;
  maxWorkers?: string | number | undefined;
  transformer?: string | undefined;
  'reset-cache'?: boolean | undefined;
  resetCache?: boolean | undefined;
  verbose?: boolean | undefined;
}>;
