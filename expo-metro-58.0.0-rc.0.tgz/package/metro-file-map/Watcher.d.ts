/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @generated SignedSource<<a7530c53514456fccc396b024853e6ab>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro-file-map/src/Watcher.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {Console, Crawler, CrawlerOptions, CrawlResult, PerfLogger, WatcherBackendChangeEvent} from './flow-types';

import EventEmitter from 'node:events';

type WatcherOptions = {
  abortSignal: AbortSignal;
  computeSha1: boolean;
  console: Console;
  /**
   * Replaces the built-in Watchman/node crawlers for all crawling, including
   * the scoped re-crawl issued on a directory-rename event in watch mode -
   * which passes `subpath` and narrowed `roots` that the crawler is expected to
   * honour, exactly as the built-ins do.
   *
   * Watching itself is unaffected: change events still come from the built-in
   * watcher backends.
   */
  crawl?: null | undefined | Crawler;
  enableSymlinks: boolean;
  extensions: ReadonlyArray<string>;
  healthCheckFilePrefix: string;
  ignoreForCrawl: (filePath: string) => boolean;
  ignorePatternForWatch: RegExp;
  previousState: CrawlerOptions['previousState'];
  perfLogger: null | undefined | PerfLogger;
  roots: ReadonlyArray<string>;
  rootDir: string;
  useWatchman: boolean;
  watch: boolean;
  watchmanDeferStates: ReadonlyArray<string>;
};
export type HealthCheckResult =
  | {
      type: 'error';
      timeout: number;
      error: Error;
      watcher: null | undefined | string;
    }
  | {
      type: 'success';
      timeout: number;
      timeElapsed: number;
      watcher: null | undefined | string;
    }
  | {
      type: 'timeout';
      timeout: number;
      watcher: null | undefined | string;
      pauseReason: null | undefined | string;
    };
export declare class Watcher extends EventEmitter {
  constructor(options: WatcherOptions);
  crawl(): Promise<CrawlResult>;
  recrawl(subpath: string, currentFileSystem: CrawlerOptions['previousState']['fileSystem']): Promise<CrawlResult>;
  watch(onChange: (change: WatcherBackendChangeEvent) => void): Promise<void>;
  close(): Promise<void>;
  checkHealth(timeout: number): Promise<HealthCheckResult>;
}
