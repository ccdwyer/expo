/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @generated SignedSource<<b8e9c8cf045ddd83ece7ba50d8eab42d>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro/src/HmrServer.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {RevisionId, default as IncrementalBundler} from './IncrementalBundler';
import type {GraphOptions} from './shared/types';
import type {ConfigT, RootPerfLogger} from '../metro-config';
import type {HmrErrorMessage, HmrUpdateMessage} from '../metro-runtime/modules/types';

export type Client = {
  optedIntoHMR: boolean;
  revisionIds: Array<RevisionId>;
  readonly sendFn: ($$PARAM_0$$: string) => void;
};
type ClientGroup = {
  readonly clients: Set<Client>;
  clientUrl: URL;
  revisionId: RevisionId;
  readonly unlisten: () => void;
  readonly graphOptions: GraphOptions;
};
/**
 * The HmrServer (Hot Module Reloading) implements a lightweight interface
 * to communicate easily to the logic in the React Native repository (which
 * is the one that handles the Web Socket connections).
 *
 * This interface allows the HmrServer to hook its own logic to WS clients
 * getting connected, disconnected or having errors (through the
 * `onClientConnect`, `onClientDisconnect` and `onClientError` methods).
 */
declare class HmrServer<TClient extends Client> {
  _config: ConfigT;
  _bundler: IncrementalBundler;
  _createModuleId: (path: string) => number;
  _clientGroups: Map<RevisionId, ClientGroup>;
  constructor(bundler: IncrementalBundler, createModuleId: (path: string) => number, config: ConfigT);
  onClientConnect: (requestUrl: string, sendFn: (data: string) => void) => Promise<Client>;
  _registerEntryPoint(client: Client, originalRequestUrl: string, sendFn: (data: string) => void): Promise<void>;
  onClientMessage: (client: TClient, message: string | Buffer | ArrayBuffer | Array<Buffer>, sendFn: (data: string) => void) => Promise<void>;
  onClientError: (client: TClient, e: Error) => void;
  onClientDisconnect: (client: TClient) => void;
  _handleFileChange(
    group: ClientGroup,
    options: {isInitialUpdate: boolean},
    changeEvent:
      | null
      | undefined
      | {
          readonly logger: null | undefined | RootPerfLogger;
          readonly changeId?: string | undefined;
        },
  ): Promise<void>;
  _prepareMessage(
    group: ClientGroup,
    options: {isInitialUpdate: boolean},
    changeEvent:
      | null
      | undefined
      | {
          readonly logger: null | undefined | RootPerfLogger;
          readonly changeId?: string | undefined;
        },
  ): Promise<HmrUpdateMessage | HmrErrorMessage>;
}
export default HmrServer;
