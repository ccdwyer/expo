module.exports = require("metro-transform-worker");
module.exports.default = module.exports;