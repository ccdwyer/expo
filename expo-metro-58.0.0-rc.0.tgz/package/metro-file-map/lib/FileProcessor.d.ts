/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @oncall react_native
 * @generated SignedSource<<827655a12450226ee664d2026476744c>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro-file-map/src/lib/FileProcessor.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {FileMapPluginWorker, FileMetadata, PerfLogger} from '../flow-types';

type ProcessFileRequest = Readonly<{
  /**
   * Populate metadata[H.SHA1] with the SHA1 of the file's contents.
   */
  computeSha1: boolean;
  /**
   * Only if processing has already required reading the file's contents, return
   * the contents as a Buffer - null otherwise. Not supported for batches.
   */
  maybeReturnContent: boolean;
}>;
interface MaybeCodedError extends Error {
  code?: string | undefined;
}
export declare class FileProcessor {
  constructor(
    opts: Readonly<{
      maxFilesPerWorker?: null | undefined | number;
      maxWorkers: number;
      pluginWorkers: null | undefined | ReadonlyArray<FileMapPluginWorker>;
      perfLogger: null | undefined | PerfLogger;
      rootDir: string;
    }>,
  );
  processBatch(
    files: ReadonlyArray<[string, FileMetadata]>,
    req: ProcessFileRequest,
  ): Promise<{
    errors: Array<{normalFilePath: string; error: MaybeCodedError}>;
  }>;
  processRegularFile(normalPath: string, fileMetadata: FileMetadata, req: ProcessFileRequest): null | undefined | {content: null | undefined | Buffer};
  end(): Promise<void>;
}
